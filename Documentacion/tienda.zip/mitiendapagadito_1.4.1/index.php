<?php
/**
 * Mi Tienda Pagadito 1.2 (API PHP)
 *
 * Es un ejemplo de plataforma de e-commerce, que realiza venta de productos
 * electrónicos, y efectúa los cobros utilizando Pagadito, a través del WSPG.
 *
 * index.php
 *
 * Es el script de la página inicial de Mi Tienda Pagadito. Aquí se muestran
 * los productos que se encuentran a la venta.
 *
 * LICENCIA: Éste código fuente es de uso libre. Su comercialización no está
 * permitida. Toda publicación o mención del mismo, debe ser referenciada a
 * su autor original Pagadito.com.
 *
 * @author      Pagadito.com <soporte@pagadito.com>
 * @copyright   Copyright (c) 2017, Pagadito.com
 * @version     1.2
 * @link        https://dev.pagadito.com/index.php?mod=docs&hac=wspg
 */
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Tienda Demo</title>
        <meta charset="UTF-8">
        <link type="text/css" rel="stylesheet" href="css/default.css" media="screen" />
        <script type="text/javascript" src="js/custom.js"></script>
    </head>
    <body>
        <div id="nav">
            <div class="title">
                <a href="#">Tienda Demo<span class="subtitle"> by pagadito.com</span></a>
            </div>
            <div class="res">
                <ul id="navigation">
                    <li><a href="#inicio">Inicio</a></li>
                    <li><a href="#descargas">Descargas</a></li>
                    <li><a href="#dev">Developers</a></li>
                </ul>
            </div>
        </div>
        <div class="clear"></div>
        <div class="wrapper">
            <label id="inicio"></label>
            <div class="seccion">Paga con Pagadito</div>
            <div class="clear"></div>
            <div class="row">
                <form action="cobro.php" method="post">
                    <div class="producto">
                        <!-- Se definen 2 campos ocultos con el precio y la descripci�n del producto 1 -->
                        <input type="hidden" value="Monitor LED" name="descripcion1" />
                        <input type="hidden" value="75.00" name="precio1" />
                        <input type="hidden" value="http://demo.pagadito.com/mitiendapagadito/index.php?item=1" name="url1" />
                        <div class="imagen"><img src="imagenes/monitor.jpg" title="Monitor" alt="Monitor" /></div>
                        <h2>Monitor LED</h2>
                        <p>17 pulgadas, con resoluciones hasta 1280 x 800 pixeles.</p>
                        <h2>US$75.00</h2>
                        <br />
                        <div class="cantidad">
                            <input type="button" value="<" onclick="dw('c11', 'c12', 'c13', '75.00')" class="updown">
                            <input id="c11" type="text" size="2" value="0" name="cantidad1" readonly="readonly"/>
                            <input type="button" value=">" onclick="up('c11', 'c12', 'c13', '75.00')" class="updown">
                        </div>
                    </div>
                    <div class="producto">
                        <!-- Se definen 2 campos ocultos con el precio y la descripci�n del producto 2 -->
                        <input type="hidden" value="Laptop" name="descripcion2" />
                        <input type="hidden" value="174.95" name="precio2" />
                        <input type="hidden" value="http://demo.pagadito.com/mitiendapagadito/index.php?item=2" name="url2" />
                        <div class="imagen"><img src="imagenes/laptop.jpg" title="Laptop" alt="Laptop" /></div>
                        <h2>Laptop</h2>
                        <p>Core 2 Duo, 4GB de RAM, 160GB HHDD.</p>
                        <h2>US$174.95</h2>
                        <br />
                        <div class="cantidad">
                            <input type="button" value="<" onclick="dw('c21', 'c22', 'c23', '174.95')" class="updown">
                            <input id="c21" type="text" size="2" value="0" name="cantidad2" readonly="readonly"/>
                            <input type="button" value=">" onclick="up('c21', 'c22', 'c23', '174.95')" class="updown">
                        </div>
                    </div>
                    <div class="producto">
                        <!-- Se definen 2 campos ocultos con el precio y la descripci�n del producto 3 -->
                        <input type="hidden" value="Teclado" name="descripcion3" />
                        <input type="hidden" value="19.99" name="precio3" />
                        <input type="hidden" value="http://demo.pagadito.com/mitiendapagadito/index.php?item=3" name="url3" />
                        <div class="imagen"><img src="imagenes/teclado.jpg" title="Teclado" alt="Teclado" /></div>
                        <h2>Teclado</h2>
                        <p>Ergon&oacute;mico codificaci&oacute;n latina y teclas de funciones especiales.</p>
                        <h2>US$19.99</h2>
                        <br />
                        <div class="cantidad">
                            <input type="button" value="<" onclick="dw('c31', 'c32', 'c33', '19.99')" class="updown">
                            <input id="c31" type="text" size="2" value="0" name="cantidad3" readonly="readonly"/>
                            <input type="button" value=">" onclick="up('c31', 'c32', 'c33', '19.99')" class="updown">
                        </div>
                    </div>
                    <div class="detalle">
                        <div class="tabla" >
                            <table>
                                <tr>
                                    <td>Producto</td><td>Cant.</td><td>Precio</td>
                                </tr>
                                <tr>
                                    <td>Monitor</td>
                                    <td><input type="text" size="2" value="0" id="c12" class="precio_tabla" readonly="readonly"/></td>
                                    <td><input type="text" size="2" value="0.00" id="c13" class="precio_tabla" readonly="readonly"/></td>
                                </tr>
                                <tr>
                                    <td>Laptop</td>
                                    <td><input type="text" size="2" value="0" id="c22" class="precio_tabla" readonly="readonly"/></td>
                                    <td><input type="text" size="2" value="0.00" id="c23" class="precio_tabla" readonly="readonly"/></td>
                                </tr>
                                <tr>
                                    <td>Teclado</td>
                                    <td><input type="text" size="2" value="0" id="c32" class="precio_tabla" readonly="readonly"/></td>
                                    <td><input type="text" size="2" value="0.00" id="c33" class="precio_tabla" readonly="readonly"/></td>
                                </tr>
                            </table>
                            <hr>
                            <input type="text" size="2" value="US$ 0.00" id="cTot" class="total_tabla" readonly="readonly"/>
                            <div class="clear"></div>
                            <p></p>
                            <input type="submit" value="Comprar" id="btnComprar" class="btnPrincipal"/>
                            <p></p>

                            <div class="info">
                                Esta Tienda es una plataforma con fines de demostraci&oacute;n y testing de Pagadito.
                            </div>

                        </div>
                    </div>
                </form>
                <div class="clear"></div>
            </div>
            <label id="descargas"></label>
            <div class="seccion">Descargas</div>
            <div class="clear"></div>
            <div class="row">
                <div class="descarga">
                    <a href="https://dev.pagadito.com/index.php?mod=docs&hac=des&file=12">
                        <img src="imagenes/cloud.png">
                    </a>
                    <label><a href="https://dev.pagadito.com/index.php?mod=docs&hac=des&file=12">Tienda demo 1.3</a></label>
                </div>
                <div class="clear"></div>
                <div class="descarga">
                    <a href="https://dev.pagadito.com/index.php?mod=docs&hac=des&file=4">
                        <img src="imagenes/cloud.png">
                    </a>
                    <label><a href="https://dev.pagadito.com/index.php?mod=docs&hac=des&file=4">API PHP</a></label>
                </div>
                <div class="clear"></div>
            </div>
            <label id="dev"></label>
            <div class="seccion">Developers</div>
            <div class="clear"></div>
            <div class="row">
                <div class="imagenDev">
                    <img src="imagenes/programador.jpg">
                </div>
                <div class="textoDev">
                    <label id="principal">&iquest;M&aacute;s informaci&oacute;n sobre c&oacute;mo integrarte a Pagadito?</label><br />
                    <br />
                    <label id="secundario">
                        Entra a <a href="http://dev.pagadito.com/index.php?mod=docs">Pagadito Developers</a><br />
                        Escr&iacute;benos a <a href="mailto:soporte@pagadito.com">soporte@pagadito.com</a><br />
                        Ll&aacute;manos al <a href="javascript:void(0);">(503) 2264-7032</a>
                    </label>
                    <br />
                </div>
            </div>
        </div>
        <div class="pie">
            <label>Pagadito&copy; <?php echo date('Y'); ?></label> <br />
            <label>Esta es una plataforma que simula la venta de productos electr&oacute;nicos y efect&uacute;a los cobros por medio de Pagadito.</label><br />
            <label>La integraci&oacute;n de este demo con Pagadito se realiza por medio de <b>API Pagadito</b>.</label>
        </div>
    </body>
</html>