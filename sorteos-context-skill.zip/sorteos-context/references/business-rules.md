# Reglas de Negocio Críticas - Sorteos

## 1. Concurrencia y Reservas

### Regla 1.1: Locks Distribuidos Obligatorios
**Contexto:** Prevenir doble venta cuando múltiples usuarios clickean el mismo número simultáneamente.

```go
// ✅ Patrón obligatorio SIEMPRE
func (uc *ReserveNumbersUseCase) Execute(ctx context.Context, input ReserveInput) error {
    locks := []string{}
    
    // 1. Adquirir locks para TODOS los números (todo o nada)
    for _, num := range input.Numbers {
        lockKey := fmt.Sprintf("lock:raffle:%d:num:%s", input.RaffleID, num)
        
        // SETNX: Set if Not eXists - atómico
        acquired := uc.redis.SetNX(ctx, lockKey, input.UserID, 30*time.Second)
        
        if !acquired.Val() {
            // Número ya reservado por otro usuario
            // Liberar TODOS los locks adquiridos hasta ahora
            for _, key := range locks {
                uc.redis.Del(ctx, key)
            }
            return domain.ErrNumberAlreadyReserved
        }
        
        locks = append(locks, lockKey)
    }
    
    // 2. TODOS los locks adquiridos exitosamente
    // Crear reserva en DB (transacción)
    defer func() {
        // 3. Liberar locks después de completar transacción
        for _, key := range locks {
            uc.redis.Del(ctx, key)
        }
    }()
    
    // ... crear reserva en DB
}
```

**Parámetros:**
- **TTL del lock:** 30 segundos (suficiente para crear reserva en DB)
- **Estrategia:** Todo o nada (si un lock falla, liberar todos)
- **Key pattern:** `lock:raffle:{raffle_id}:num:{number}`

### Regla 1.2: Máximo 10 Números por Reserva
**Razón:** Prevenir acaparamiento de números por un solo usuario.

```go
const MaxNumbersPerReservation = 10

if len(input.Numbers) > MaxNumbersPerReservation {
    return domain.ErrTooManyNumbers
}
```

### Regla 1.3: Reserva Expira en 5 Minutos
**Razón:** Liberar números para otros usuarios si no completa pago.

```go
func (uc *ReserveNumbersUseCase) Execute(ctx context.Context, input ReserveInput) error {
    reservation := &domain.Reservation{
        UserID:    input.UserID,
        RaffleID:  input.RaffleID,
        Numbers:   input.Numbers,
        Status:    domain.ReservationStatusPending,
        ExpiresAt: time.Now().Add(5 * time.Minute),  // Exactamente 5 minutos
        CreatedAt: time.Now(),
    }
    
    // ... persistir
}
```

### Regla 1.4: Limpieza Automática de Reservas Expiradas
**Implementación:** Cron job cada 1 minuto.

```go
// cmd/api/jobs.go
func StartReservationCleanupJob(db *gorm.DB, logger *zap.Logger) {
    ticker := time.NewTicker(1 * time.Minute)
    
    go func() {
        for range ticker.C {
            cleanExpiredReservations(db, logger)
        }
    }()
}

func cleanExpiredReservations(db *gorm.DB, logger *zap.Logger) {
    now := time.Now()
    
    // Buscar reservas expiradas
    var expired []ReservationModel
    db.Where("status = ? AND expires_at < ?", "pending", now).Find(&expired)
    
    for _, res := range expired {
        tx := db.Begin()
        
        // 1. Actualizar reserva a expirada
        tx.Model(&res).Update("status", "expired")
        
        // 2. Liberar números
        tx.Model(&RaffleNumberModel{}).
            Where("raffle_id = ? AND user_id = ? AND status = ?", 
                  res.RaffleID, res.UserID, "reserved").
            Updates(map[string]interface{}{
                "status":  "available",
                "user_id": nil,
            })
        
        tx.Commit()
        
        logger.Info("expired reservation cleaned",
            zap.Int64("reservation_id", res.ID),
            zap.Int64("user_id", res.UserID),
            zap.Int("numbers_freed", len(res.Numbers)),
        )
    }
}
```

---

## 2. Pagos e Idempotencia

### Regla 2.1: Idempotencia Obligatoria en Pagos
**Contexto:** Usuario hace doble click, o frontend hace retry → NO crear pago duplicado.

**Backend:**
```go
func (h *PaymentHandler) ProcessPayment(c *gin.Context) {
    // 1. Idempotency-Key es OBLIGATORIO
    idempKey := c.GetHeader("Idempotency-Key")
    if idempKey == "" {
        c.JSON(400, gin.H{"error": "Idempotency-Key header required"})
        return
    }
    
    // 2. Verificar si ya existe en Redis (24h TTL)
    cacheKey := fmt.Sprintf("payment:idemp:%s", idempKey)
    cached := h.redis.Get(c.Request.Context(), cacheKey).Val()
    
    if cached != "" {
        var existingPayment domain.Payment
        json.Unmarshal([]byte(cached), &existingPayment)
        
        h.logger.Info("idempotent payment request",
            zap.String("idempotency_key", idempKey),
            zap.Int64("payment_id", existingPayment.ID),
        )
        
        c.JSON(200, existingPayment)  // Retornar pago anterior
        return
    }
    
    // 3. Procesar nuevo pago
    payment, err := h.useCase.Execute(c.Request.Context(), input)
    if err != nil {
        h.handleError(c, err)
        return
    }
    
    // 4. Guardar en cache (24h TTL)
    paymentJSON, _ := json.Marshal(payment)
    h.redis.Set(c.Request.Context(), cacheKey, paymentJSON, 24*time.Hour)
    
    c.JSON(201, payment)
}
```

**Frontend:**
```typescript
import { v4 as uuidv4 } from 'uuid'

// ✅ BIEN: Generar UUID UNA SOLA VEZ
const processPayment = async (reservationId: string) => {
  const idempotencyKey = uuidv4()  // Generado al inicio
  
  try {
    const response = await api.post('/payments', {
      reservation_id: reservationId,
      payment_method_id: stripePaymentMethodId,
    }, {
      headers: {
        'Idempotency-Key': idempotencyKey  // Mismo UUID en retry
      }
    })
    
    return response.data
  } catch (error) {
    if (isRetriableError(error)) {
      // Retry con MISMO idempotencyKey
      return api.post('/payments', { ... }, {
        headers: { 'Idempotency-Key': idempotencyKey }  // ✅ Mismo UUID
      })
    }
  }
}

// ❌ MAL: Generar nuevo UUID en cada request
const processPayment = async (reservationId: string) => {
  await api.post('/payments', { ... }, {
    headers: {
      'Idempotency-Key': uuidv4()  // ❌ Nuevo UUID = nuevo pago
    }
  })
}
```

### Regla 2.2: Números Solo "sold" Cuando Pago Confirmado
**Razón:** Prevenir venta de números si pago falla.

**Estados de números:**
```
available → reserved (al crear reserva)
reserved → sold (al confirmar pago vía webhook)
reserved → available (al expirar reserva)
```

**Implementación:**
```go
// Webhook de Stripe
func (h *WebhookHandler) HandleStripeWebhook(c *gin.Context) {
    event := stripe.ParseEvent(payload)
    
    if event.Type == "payment_intent.succeeded" {
        var pi stripe.PaymentIntent
        json.Unmarshal(event.Data.Raw, &pi)
        
        reservationID := pi.Metadata["reservation_id"]
        
        tx := h.db.Begin()
        
        // 1. Actualizar payment
        tx.Model(&PaymentModel{}).
            Where("stripe_payment_intent_id = ?", pi.ID).
            Update("status", "succeeded")
        
        // 2. Actualizar reserva
        tx.Model(&ReservationModel{}).
            Where("id = ?", reservationID).
            Update("status", "confirmed")
        
        // 3. Marcar números como SOLD (crítico)
        tx.Model(&RaffleNumberModel{}).
            Where("reservation_id = ?", reservationID).
            Updates(map[string]interface{}{
                "status":  "sold",  // ✅ Solo aquí cambia a sold
                "sold_at": time.Now(),
            })
        
        tx.Commit()
    }
}
```

### Regla 2.3: Refund Automático si Webhook Llega Post-Expiración
**Contexto:** Webhook de Stripe puede tardar minutos. Si reserva expiró, hacer refund.

```go
func (h *WebhookHandler) HandleStripeWebhook(c *gin.Context) {
    // ... obtener reservation
    
    if reservation.Status == domain.ReservationStatusExpired {
        // Reserva expiró mientras pago se procesaba
        // Hacer refund automático
        refund, err := h.stripeClient.Refunds.New(&stripe.RefundParams{
            PaymentIntent: &pi.ID,
            Reason:        stripe.String("expired"),
        })
        
        if err != nil {
            h.logger.Error("failed to refund expired reservation",
                zap.Error(err),
                zap.String("payment_intent", pi.ID),
            )
            // Escalar a admin para refund manual
            h.alertAdmin(reservation, pi.ID)
        }
        
        return
    }
    
    // ... continuar con confirmación normal
}
```

---

## 3. KYC y Trust Levels

### Regla 3.1: Niveles de Verificación

```go
type KYCLevel string

const (
    KYCLevelNone           KYCLevel = "none"             // Recién registrado
    KYCLevelEmailVerified  KYCLevel = "email_verified"   // Email verificado
    KYCLevelPhoneVerified  KYCLevel = "phone_verified"   // Email + teléfono (Fase 2)
    KYCLevelFullKYC        KYCLevel = "full_kyc"         // Cédula validada (Fase 2)
)
```

### Regla 3.2: Permisos por Nivel

| Acción | none | email_verified | phone_verified | full_kyc |
|--------|------|----------------|----------------|----------|
| Ver sorteos | ✅ | ✅ | ✅ | ✅ |
| Crear sorteos | ❌ | ✅ | ✅ | ✅ |
| Comprar boletos | ❌ | ✅ (hasta ₡10k) | ✅ (hasta ₡50k) | ✅ (sin límite) |
| Retirar fondos | ❌ | ❌ | ❌ | ✅ |

**Implementación:**
```go
func (u *User) CanCreateRaffle() bool {
    return u.KYCLevel >= KYCLevelEmailVerified && u.Status == UserStatusActive
}

func (u *User) CanPurchaseTickets() bool {
    return u.KYCLevel >= KYCLevelEmailVerified && u.Status == UserStatusActive
}

func (u *User) GetPurchaseLimit() decimal.Decimal {
    switch u.KYCLevel {
    case KYCLevelNone:
        return decimal.Zero
    case KYCLevelEmailVerified:
        return decimal.NewFromInt(10000)  // ₡10,000
    case KYCLevelPhoneVerified:
        return decimal.NewFromInt(50000)  // ₡50,000
    case KYCLevelFullKYC:
        return decimal.NewFromInt(999999999)  // Sin límite práctico
    default:
        return decimal.Zero
    }
}
```

---

## 4. Sorteos

### Regla 4.1: Máximo 10 Sorteos Activos por Usuario
**Razón:** Prevenir spam de sorteos de baja calidad.

```go
const MaxActivRafflesPerUser = 10

func (uc *CreateRaffleUseCase) Execute(ctx context.Context, input CreateRaffleInput) error {
    // Verificar límite de sorteos activos
    count, err := uc.raffleRepo.CountActiveByUserID(ctx, input.UserID)
    if err != nil {
        return err
    }
    
    if count >= MaxActiveRafflesPerUser {
        return domain.ErrMaxActiveRafflesReached
    }
    
    // ... continuar creación
}
```

**Nota:** Admin puede aumentar límite para usuarios premium (Fase 2).

### Regla 4.2: DrawDate Mínimo 24 Horas en el Futuro
**Razón:** Dar tiempo suficiente para ventas.

```go
func validateDrawDate(drawDate time.Time) error {
    minDrawDate := time.Now().Add(24 * time.Hour)
    
    if drawDate.Before(minDrawDate) {
        return fmt.Errorf("draw date must be at least 24 hours in the future")
    }
    
    return nil
}
```

### Regla 4.3: Precio por Número: ₡100 - ₡10,000
**Razón:** Rango razonable para rifas/sorteos en Costa Rica.

```go
var (
    MinPricePerNumber = decimal.NewFromInt(100)      // ₡100
    MaxPricePerNumber = decimal.NewFromInt(10000)    // ₡10,000
)

func validatePrice(price decimal.Decimal) error {
    if price.LessThan(MinPricePerNumber) {
        return fmt.Errorf("price must be at least %s", MinPricePerNumber)
    }
    
    if price.GreaterThan(MaxPricePerNumber) {
        return fmt.Errorf("price must not exceed %s", MaxPricePerNumber)
    }
    
    return nil
}
```

### Regla 4.4: Imágenes: Mínimo 1, Máximo 5
**Razón:** Balance entre presentación y performance.

```go
const (
    MinImagesPerRaffle = 1
    MaxImagesPerRaffle = 5
    MaxImageSize       = 2 * 1024 * 1024  // 2 MB
)

func validateImages(images []UploadedImage) error {
    if len(images) < MinImagesPerRaffle {
        return fmt.Errorf("at least %d image required", MinImagesPerRaffle)
    }
    
    if len(images) > MaxImagesPerRaffle {
        return fmt.Errorf("maximum %d images allowed", MaxImagesPerRaffle)
    }
    
    for _, img := range images {
        if img.Size > MaxImageSize {
            return fmt.Errorf("image %s exceeds maximum size of 2 MB", img.Name)
        }
        
        if !isAllowedImageType(img.ContentType) {
            return fmt.Errorf("image %s has invalid type: %s", img.Name, img.ContentType)
        }
    }
    
    return nil
}

func isAllowedImageType(contentType string) bool {
    allowed := []string{"image/jpeg", "image/png", "image/webp"}
    for _, t := range allowed {
        if t == contentType {
            return true
        }
    }
    return false
}
```

### Regla 4.5: Solo Owner Puede Editar/Publicar
**Implementación:**

```go
func (h *RaffleHandler) UpdateRaffle(c *gin.Context) {
    raffleID := c.Param("id")
    userID := c.GetInt64("user_id")  // Del JWT
    
    raffle, err := h.raffleRepo.FindByID(c.Request.Context(), raffleID)
    if err != nil {
        c.JSON(404, gin.H{"error": "raffle not found"})
        return
    }
    
    // Verificar ownership
    if raffle.OwnerID != userID {
        c.JSON(403, gin.H{"error": "you are not the owner of this raffle"})
        return
    }
    
    // ... continuar actualización
}
```

**Excepción:** Admin puede editar cualquier sorteo (moderación).

### Regla 4.6: Estados de Sorteo

```go
type RaffleStatus string

const (
    RaffleStatusDraft      RaffleStatus = "draft"       // Creado, no visible públicamente
    RaffleStatusActive     RaffleStatus = "active"      // Publicado, aceptando compras
    RaffleStatusSuspended  RaffleStatus = "suspended"   // Suspendido por admin
    RaffleStatusCompleted  RaffleStatus = "completed"   // Sorteo realizado
    RaffleStatusCancelled  RaffleStatus = "cancelled"   // Cancelado con reembolsos
)
```

**Transiciones válidas:**
```
draft → active (owner publica)
active → suspended (admin suspende)
suspended → active (admin reactiva)
active → completed (cron job sortea ganador)
active → cancelled (admin cancela con reembolso)
```

---

## 5. Comisiones y Settlements

### Regla 5.1: Comisión de Plataforma
**Configurable por sorteo:**

```go
type Raffle struct {
    // ...
    PlatformFeePercent decimal.Decimal  // 5-10% típico
}

const (
    DefaultPlatformFeePercent = 5.0    // 5%
    MinPlatformFeePercent     = 3.0    // 3%
    MaxPlatformFeePercent     = 15.0   // 15%
)

func (r *Raffle) CalculateNetAmount() decimal.Decimal {
    totalSales := r.PricePerNumber.Mul(decimal.NewFromInt(int64(r.NumbersSold)))
    platformFee := totalSales.Mul(r.PlatformFeePercent).Div(decimal.NewFromInt(100))
    netAmount := totalSales.Sub(platformFee)
    
    return netAmount
}
```

### Regla 5.2: Mínimo 60% de Números Vendidos
**Razón:** Garantizar viabilidad económica del sorteo.

```go
const MinSoldPercentageToExecuteDraw = 60.0

func (r *Raffle) CanExecuteDraw() bool {
    totalNumbers := r.MaxNumber - r.MinNumber + 1
    soldPercentage := (float64(r.NumbersSold) / float64(totalNumbers)) * 100
    
    return soldPercentage >= MinSoldPercentageToExecuteDraw
}
```

**Si no se alcanza mínimo:**
- Sorteo se cancela automáticamente
- Todos los compradores reciben reembolso
- Owner es notificado

### Regla 5.3: Retiro Mínimo: ₡10,000
**Razón:** Evitar micro-transacciones costosas.

```go
const MinWithdrawalAmount = 10000  // ₡10,000

func (uc *WithdrawFundsUseCase) Execute(ctx context.Context, input WithdrawInput) error {
    if input.Amount.LessThan(decimal.NewFromInt(MinWithdrawalAmount)) {
        return fmt.Errorf("minimum withdrawal amount is ₡%d", MinWithdrawalAmount)
    }
    
    // ... procesar retiro
}
```

---

## 6. Seguridad

### Regla 6.1: Rate Limiting por Endpoint

| Endpoint | Límite | Ventana | Por |
|----------|--------|---------|-----|
| `POST /auth/login` | 5 requests | 1 minuto | IP |
| `POST /auth/register` | 3 requests | 1 hora | IP |
| `POST /reservations` | 10 requests | 1 minuto | user_id |
| `POST /payments` | 5 requests | 1 minuto | user_id |
| `GET /raffles` | 60 requests | 1 minuto | IP |

**Implementación:**
```go
func RateLimitMiddleware(limit int, window time.Duration, keyFunc func(*gin.Context) string) gin.HandlerFunc {
    return func(c *gin.Context) {
        key := fmt.Sprintf("ratelimit:%s", keyFunc(c))
        
        count, _ := rdb.Incr(c.Request.Context(), key).Result()
        if count == 1 {
            rdb.Expire(c.Request.Context(), key, window)
        }
        
        if count > int64(limit) {
            c.JSON(429, gin.H{"error": "too many requests"})
            c.Abort()
            return
        }
        
        c.Next()
    }
}

// Uso
authGroup.POST("/login", 
    RateLimitMiddleware(5, 1*time.Minute, func(c *gin.Context) string {
        return c.ClientIP()  // Rate limit por IP
    }),
    authHandler.Login,
)

reservationsGroup.POST("",
    AuthMiddleware(),
    RateLimitMiddleware(10, 1*time.Minute, func(c *gin.Context) string {
        return fmt.Sprint(c.GetInt64("user_id"))  // Rate limit por user
    }),
    reservationHandler.Create,
)
```

### Regla 6.2: Contraseñas
**Requisitos obligatorios:**

```go
func ValidatePassword(password string) error {
    if len(password) < 12 {
        return errors.New("password must be at least 12 characters")
    }
    
    hasUpper := regexp.MustCompile(`[A-Z]`).MatchString(password)
    hasLower := regexp.MustCompile(`[a-z]`).MatchString(password)
    hasDigit := regexp.MustCompile(`[0-9]`).MatchString(password)
    hasSymbol := regexp.MustCompile(`[^A-Za-z0-9]`).MatchString(password)
    
    if !hasUpper {
        return errors.New("password must contain at least one uppercase letter")
    }
    if !hasLower {
        return errors.New("password must contain at least one lowercase letter")
    }
    if !hasDigit {
        return errors.New("password must contain at least one digit")
    }
    if !hasSymbol {
        return errors.New("password must contain at least one special character")
    }
    
    return nil
}
```

**Hashing:**
```go
import "golang.org/x/crypto/bcrypt"

const bcryptCost = 12  // Balance seguridad/performance

func HashPassword(password string) (string, error) {
    hash, err := bcrypt.GenerateFromPassword([]byte(password), bcryptCost)
    return string(hash), err
}

func VerifyPassword(hash, password string) bool {
    err := bcrypt.CompareHashAndPassword([]byte(hash), []byte(password))
    return err == nil
}
```

---

## Checklist de Reglas de Negocio

**Al implementar nueva funcionalidad, verificar:**

✅ **Concurrencia:**
- [ ] ¿Usa locks distribuidos para recursos compartidos?
- [ ] ¿Maneja expiración de reservas?
- [ ] ¿Libera recursos en caso de error?

✅ **Pagos:**
- [ ] ¿Implementa idempotencia con Idempotency-Key?
- [ ] ¿Verifica en cache antes de procesar?
- [ ] ¿Maneja webhooks con verificación de firma?

✅ **KYC:**
- [ ] ¿Verifica nivel de verificación del usuario?
- [ ] ¿Respeta límites por nivel?

✅ **Sorteos:**
- [ ] ¿Valida rangos de precio, fecha, imágenes?
- [ ] ¿Verifica ownership en operaciones?
- [ ] ¿Respeta límite de sorteos activos?

✅ **Seguridad:**
- [ ] ¿Aplica rate limiting?
- [ ] ¿Valida contraseñas robustas?
- [ ] ¿Logging estructurado de acciones sensibles?
