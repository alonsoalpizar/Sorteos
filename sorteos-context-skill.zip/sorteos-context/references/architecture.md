# Arquitectura - Sorteos

## Arquitectura Hexagonal (Ports & Adapters)

### Capas y Responsabilidades

```
┌─────────────────────────────────────────────────────────────┐
│                       ADAPTERS (Driving)                     │
│                    HTTP Handlers (Gin)                       │
│              GET /raffles, POST /auth/login, etc.           │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│                        USE CASES                             │
│              Lógica de aplicación (orquestación)            │
│     RegisterUser, CreateRaffle, ReserveNumbers, etc.        │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│                          DOMAIN                              │
│                  Entidades + Interfaces (Ports)             │
│          User, Raffle, UserRepository, PaymentProvider      │
└─────────────────────────────────────────────────────────────┘
                              ↑
┌─────────────────────────────────────────────────────────────┐
│                      ADAPTERS (Driven)                       │
│      Implementaciones: PostgreSQL, Redis, Stripe, SMTP      │
└─────────────────────────────────────────────────────────────┘
```

### 1. Domain Layer (internal/domain/)

**Responsabilidad:** Entidades de negocio + Interfaces (contratos)
**Imports permitidos:** Solo stdlib + otros packages de domain
**Exports:** Todo público (PascalCase)

```go
// internal/domain/user.go
package domain

import (
    "context"
    "time"
)

// Entidad pura - sin tags de DB/JSON aquí
type User struct {
    ID           int64
    Email        string
    PasswordHash string
    FirstName    string
    LastName     string
    Role         UserRole
    KYCLevel     KYCLevel
    Status       UserStatus
    CreatedAt    time.Time
    UpdatedAt    time.Time
}

// Port (interfaz) - define contrato
type UserRepository interface {
    Create(ctx context.Context, user *User) error
    FindByID(ctx context.Context, id int64) (*User, error)
    FindByEmail(ctx context.Context, email string) (*User, error)
    Update(ctx context.Context, user *User) error
}

// Enums
type UserRole string
const (
    RoleUser  UserRole = "user"
    RoleAdmin UserRole = "admin"
)

// Métodos de negocio en entidad
func (u *User) IsEmailVerified() bool {
    return u.KYCLevel >= KYCLevelEmailVerified
}

func (u *User) CanCreateRaffle() bool {
    return u.IsEmailVerified() && u.Status == UserStatusActive
}
```

**❌ NUNCA en domain:**
```go
import "gorm.io/gorm"              // ¡NO! Es implementación
import "github.com/gin-gonic/gin"  // ¡NO! Es framework HTTP
import "github.com/stripe/stripe-go" // ¡NO! Es provider específico
```

### 2. Use Case Layer (internal/usecase/)

**Responsabilidad:** Lógica de aplicación (orquestación de dominio)
**Imports permitidos:** domain/ + stdlib + pkg/
**Dependencies:** Inyectadas vía constructor

```go
// internal/usecase/auth/register.go
package auth

import (
    "context"
    "errors"
    
    "sorteos/internal/domain"
    "sorteos/pkg/crypto"
    "sorteos/pkg/logger"
)

type RegisterUseCase struct {
    userRepo    domain.UserRepository      // Depende de interfaz
    emailSender domain.EmailSender         // Depende de interfaz
    logger      logger.Logger
}

// Constructor con inyección de dependencias
func NewRegisterUseCase(
    userRepo domain.UserRepository,
    emailSender domain.EmailSender,
    logger logger.Logger,
) *RegisterUseCase {
    return &RegisterUseCase{
        userRepo:    userRepo,
        emailSender: emailSender,
        logger:      logger,
    }
}

type RegisterInput struct {
    Email     string
    Password  string
    FirstName string
    LastName  string
}

func (uc *RegisterUseCase) Execute(ctx context.Context, input RegisterInput) (*domain.User, error) {
    // 1. Validaciones de negocio
    if err := validateEmail(input.Email); err != nil {
        return nil, err
    }
    
    // 2. Verificar unicidad
    existing, _ := uc.userRepo.FindByEmail(ctx, input.Email)
    if existing != nil {
        return nil, domain.ErrEmailAlreadyExists
    }
    
    // 3. Hash de contraseña
    hash, err := crypto.HashPassword(input.Password)
    if err != nil {
        uc.logger.Error("failed to hash password", "error", err)
        return nil, err
    }
    
    // 4. Crear entidad
    user := &domain.User{
        Email:        input.Email,
        PasswordHash: hash,
        FirstName:    input.FirstName,
        LastName:     input.LastName,
        Role:         domain.RoleUser,
        KYCLevel:     domain.KYCLevelNone,
        Status:       domain.UserStatusActive,
    }
    
    // 5. Persistir (delegar al repository)
    if err := uc.userRepo.Create(ctx, user); err != nil {
        uc.logger.Error("failed to create user", "error", err, "email", input.Email)
        return nil, err
    }
    
    // 6. Enviar email de verificación (async)
    go uc.sendVerificationEmail(user)
    
    return user, nil
}
```

**❌ NUNCA en usecase:**
```go
import "gorm.io/gorm"              // ¡NO! Implementación de DB
import "github.com/gin-gonic/gin"  // ¡NO! Framework HTTP

// ❌ Acceder directamente a DB
db.Where("email = ?", email).First(&user)

// ✅ Usar repository
user, err := uc.userRepo.FindByEmail(ctx, email)
```

### 3. Adapter Layer (internal/adapters/)

**Responsabilidad:** Implementaciones técnicas (Driving + Driven)

#### 3.1 Driving Adapters (Entradas) - HTTP Handlers

```go
// internal/adapters/http/auth_handler.go
package http

import (
    "net/http"
    
    "github.com/gin-gonic/gin"
    
    "sorteos/internal/usecase/auth"
    "sorteos/pkg/logger"
)

type AuthHandler struct {
    registerUC *auth.RegisterUseCase
    loginUC    *auth.LoginUseCase
    logger     logger.Logger
}

func NewAuthHandler(
    registerUC *auth.RegisterUseCase,
    loginUC *auth.LoginUseCase,
    logger logger.Logger,
) *AuthHandler {
    return &AuthHandler{
        registerUC: registerUC,
        loginUC:    loginUC,
        logger:     logger,
    }
}

type RegisterRequest struct {
    Email     string `json:"email" binding:"required,email"`
    Password  string `json:"password" binding:"required,min=12"`
    FirstName string `json:"first_name" binding:"required"`
    LastName  string `json:"last_name" binding:"required"`
}

func (h *AuthHandler) Register(c *gin.Context) {
    var req RegisterRequest
    if err := c.ShouldBindJSON(&req); err != nil {
        c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
        return
    }
    
    // Convertir request HTTP a input de use case
    input := auth.RegisterInput{
        Email:     req.Email,
        Password:  req.Password,
        FirstName: req.FirstName,
        LastName:  req.LastName,
    }
    
    // Ejecutar use case
    user, err := h.registerUC.Execute(c.Request.Context(), input)
    if err != nil {
        h.handleError(c, err)
        return
    }
    
    // Convertir entidad a response HTTP
    c.JSON(http.StatusCreated, toUserResponse(user))
}
```

#### 3.2 Driven Adapters (Salidas) - Repositories

```go
// internal/adapters/db/postgres_user_repository.go
package db

import (
    "context"
    "errors"
    
    "gorm.io/gorm"
    
    "sorteos/internal/domain"
)

// Modelo de DB (con tags GORM)
type UserModel struct {
    ID           int64  `gorm:"primaryKey"`
    Email        string `gorm:"uniqueIndex;not null"`
    PasswordHash string `gorm:"not null"`
    FirstName    string
    LastName     string
    Role         string
    KYCLevel     string
    Status       string
    CreatedAt    time.Time
    UpdatedAt    time.Time
}

func (UserModel) TableName() string {
    return "users"
}

// Implementación del repository
type PostgresUserRepository struct {
    db *gorm.DB
}

func NewPostgresUserRepository(db *gorm.DB) *PostgresUserRepository {
    return &PostgresUserRepository{db: db}
}

// Implementa interfaz domain.UserRepository
func (r *PostgresUserRepository) Create(ctx context.Context, user *domain.User) error {
    model := toUserModel(user)
    
    if err := r.db.WithContext(ctx).Create(&model).Error; err != nil {
        return err
    }
    
    user.ID = model.ID
    user.CreatedAt = model.CreatedAt
    user.UpdatedAt = model.UpdatedAt
    
    return nil
}

func (r *PostgresUserRepository) FindByEmail(ctx context.Context, email string) (*domain.User, error) {
    var model UserModel
    
    err := r.db.WithContext(ctx).Where("email = ?", email).First(&model).Error
    if errors.Is(err, gorm.ErrRecordNotFound) {
        return nil, domain.ErrUserNotFound
    }
    if err != nil {
        return nil, err
    }
    
    return toDomainUser(&model), nil
}

// Mappers entre domain y DB model
func toUserModel(user *domain.User) *UserModel {
    return &UserModel{
        ID:           user.ID,
        Email:        user.Email,
        PasswordHash: user.PasswordHash,
        FirstName:    user.FirstName,
        LastName:     user.LastName,
        Role:         string(user.Role),
        KYCLevel:     string(user.KYCLevel),
        Status:       string(user.Status),
        CreatedAt:    user.CreatedAt,
        UpdatedAt:    user.UpdatedAt,
    }
}

func toDomainUser(model *UserModel) *domain.User {
    return &domain.User{
        ID:           model.ID,
        Email:        model.Email,
        PasswordHash: model.PasswordHash,
        FirstName:    model.FirstName,
        LastName:     model.LastName,
        Role:         domain.UserRole(model.Role),
        KYCLevel:     domain.KYCLevel(model.KYCLevel),
        Status:       domain.UserStatus(model.Status),
        CreatedAt:    model.CreatedAt,
        UpdatedAt:    model.UpdatedAt,
    }
}
```

#### 3.3 Driven Adapters - Payment Providers

```go
// internal/adapters/payments/stripe_provider.go
package payments

import (
    "context"
    
    "github.com/stripe/stripe-go/v76"
    "github.com/stripe/stripe-go/v76/paymentintent"
    
    "sorteos/internal/domain"
)

type StripeProvider struct {
    apiKey string
}

func NewStripeProvider(apiKey string) *StripeProvider {
    stripe.Key = apiKey
    return &StripeProvider{apiKey: apiKey}
}

// Implementa interfaz domain.PaymentProvider
func (p *StripeProvider) Authorize(ctx context.Context, input domain.AuthorizeInput) (*domain.AuthorizeOutput, error) {
    params := &stripe.PaymentIntentParams{
        Amount:   stripe.Int64(input.Amount.IntPart()),
        Currency: stripe.String("crc"), // Colones costarricenses
        Metadata: map[string]string{
            "reservation_id": input.ReservationID,
            "user_id":        fmt.Sprint(input.UserID),
        },
    }
    
    pi, err := paymentintent.New(params)
    if err != nil {
        return nil, err
    }
    
    return &domain.AuthorizeOutput{
        PaymentID:     pi.ID,
        Status:        mapStripeStatus(pi.Status),
        RequiresAction: pi.Status == stripe.PaymentIntentStatusRequiresAction,
        ActionURL:     pi.NextAction.RedirectToURL.URL,
    }, nil
}
```

### 4. Wire-up (Dependency Injection)

```go
// cmd/api/main.go
package main

import (
    "sorteos/internal/adapters/db"
    "sorteos/internal/adapters/http"
    "sorteos/internal/adapters/payments"
    "sorteos/internal/usecase/auth"
    "sorteos/pkg/config"
    "sorteos/pkg/logger"
)

func main() {
    // Config
    cfg := config.Load()
    log := logger.New(cfg.LogLevel)
    
    // DB
    dbConn := db.NewConnection(cfg.DatabaseURL)
    
    // Repositories (Driven Adapters)
    userRepo := db.NewPostgresUserRepository(dbConn)
    raffleRepo := db.NewPostgresRaffleRepository(dbConn)
    
    // External Services (Driven Adapters)
    emailSender := email.NewSMTPSender(cfg.SMTP)
    paymentProvider := payments.NewStripeProvider(cfg.StripeAPIKey)
    
    // Use Cases
    registerUC := auth.NewRegisterUseCase(userRepo, emailSender, log)
    loginUC := auth.NewLoginUseCase(userRepo, log)
    createRaffleUC := raffle.NewCreateRaffleUseCase(raffleRepo, log)
    
    // Handlers (Driving Adapters)
    authHandler := http.NewAuthHandler(registerUC, loginUC, log)
    raffleHandler := http.NewRaffleHandler(createRaffleUC, log)
    
    // Router
    router := gin.Default()
    router.POST("/api/v1/auth/register", authHandler.Register)
    router.POST("/api/v1/auth/login", authHandler.Login)
    router.POST("/api/v1/raffles", authHandler.AuthMiddleware(), raffleHandler.Create)
    
    router.Run(":8080")
}
```

---

## Beneficios de Arquitectura Hexagonal

### 1. Testabilidad

```go
// Test de use case SIN bases de datos ni HTTP
func TestRegisterUseCase(t *testing.T) {
    // Mock repository
    mockRepo := &MockUserRepository{
        users: make(map[string]*domain.User),
    }
    
    // Mock email sender
    mockEmail := &MockEmailSender{}
    
    // Use case bajo test
    uc := auth.NewRegisterUseCase(mockRepo, mockEmail, logger.NewNoop())
    
    // Execute
    user, err := uc.Execute(context.Background(), auth.RegisterInput{
        Email:     "test@example.com",
        Password:  "SecurePass123!",
        FirstName: "John",
        LastName:  "Doe",
    })
    
    assert.NoError(t, err)
    assert.NotNil(t, user)
    assert.Equal(t, "test@example.com", user.Email)
}
```

### 2. Independencia de Frameworks

```go
// Cambiar de Gin a Echo (o cualquier otro framework) NO afecta use cases
// Solo cambias internal/adapters/http/

// Gin
router.POST("/raffles", handler.Create)

// Echo
e.POST("/raffles", handler.Create)

// Use case permanece IDÉNTICO
```

### 3. Independencia de DB

```go
// Cambiar de PostgreSQL a MySQL (o MongoDB) NO afecta use cases
// Solo cambias internal/adapters/db/

// PostgreSQL
type PostgresUserRepository struct { db *gorm.DB }

// MongoDB
type MongoUserRepository struct { collection *mongo.Collection }

// Domain y Use Cases permanecen IDÉNTICOS
```

### 4. Múltiples PSPs (Payment Service Providers)

```go
// Múltiples implementaciones de domain.PaymentProvider
type StripeProvider struct { ... }
type PayPalProvider struct { ... }
type LocalCRProvider struct { ... }

// Factory para seleccionar en runtime
func NewPaymentProvider(providerType string, config Config) domain.PaymentProvider {
    switch providerType {
    case "stripe":
        return NewStripeProvider(config.Stripe)
    case "paypal":
        return NewPayPalProvider(config.PayPal)
    case "local_cr":
        return NewLocalCRProvider(config.LocalCR)
    default:
        panic("unknown provider")
    }
}

// Use case permanece IDÉNTICO - depende de interfaz
```

---

## Separación Backend/Frontend

### Backend (API RESTful)

- **Puerto:** 8080
- **Endpoints:** `/api/v1/*`
- **Autenticación:** JWT en header `Authorization: Bearer <token>`
- **Responsabilidad:**
  - Exponer API
  - Servir archivos estáticos del frontend desde `/frontend/dist/`

```go
// cmd/api/routes.go
func SetupRoutes(router *gin.Engine) {
    // API routes
    api := router.Group("/api/v1")
    {
        auth := api.Group("/auth")
        {
            auth.POST("/register", authHandler.Register)
            auth.POST("/login", authHandler.Login)
        }
        
        raffles := api.Group("/raffles")
        {
            raffles.GET("", raffleHandler.List)
            raffles.POST("", authMiddleware(), raffleHandler.Create)
        }
    }
    
    // Servir frontend SPA (React)
    router.Static("/assets", "/opt/Sorteos/frontend/dist/assets")
    router.StaticFile("/", "/opt/Sorteos/frontend/dist/index.html")
    router.NoRoute(func(c *gin.Context) {
        c.File("/opt/Sorteos/frontend/dist/index.html")  // SPA fallback
    })
}
```

### Frontend (SPA)

- **Framework:** React 18 + TypeScript
- **Build:** Vite → archivos estáticos en `dist/`
- **Comunicación:** HTTP requests (Axios) → Backend API
- **Autenticación:** JWT almacenado en memoria (zustand store)

```typescript
// lib/api.ts
import axios from 'axios'

const api = axios.create({
  baseURL: '/api/v1',  // Proxy en desarrollo: Vite → localhost:8080
  timeout: 30000,
})

// Interceptor: Agregar JWT a todas las requests
api.interceptors.request.use(config => {
  const token = useAuthStore.getState().accessToken
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

// Interceptor: Refresh token si 401
api.interceptors.response.use(
  response => response,
  async error => {
    if (error.response?.status === 401) {
      // Intentar refresh
      const newToken = await refreshAccessToken()
      if (newToken) {
        error.config.headers.Authorization = `Bearer ${newToken}`
        return api.request(error.config)  // Retry
      }
      // Si falla, logout
      useAuthStore.getState().logout()
      window.location.href = '/login'
    }
    return Promise.reject(error)
  }
)

export default api
```

### Flujo de Deployment

```
1. Build frontend:
   cd /opt/Sorteos/frontend
   npm run build  → genera dist/

2. Backend sirve frontend:
   Go binary sirve archivos estáticos desde dist/
   
3. Nginx proxy reverso:
   https://sorteos.club → localhost:8080
   
4. Usuario accede:
   https://sorteos.club
   ↓
   Nginx (443)
   ↓
   Backend Go (8080) → Retorna index.html
   ↓
   Browser carga React SPA
   ↓
   React hace requests a /api/v1/* → Backend Go
```

---

## Checklist de Arquitectura

**Al crear nuevo código, verificar:**

✅ **Domain:**
- [ ] ¿Entidades puras sin tags de DB/JSON?
- [ ] ¿Solo imports de stdlib + domain?
- [ ] ¿Interfaces definen contratos?

✅ **Use Cases:**
- [ ] ¿Depende solo de interfaces (ports)?
- [ ] ¿No importa GORM, Gin, Stripe directamente?
- [ ] ¿Lógica de negocio clara y testeable?

✅ **Adapters:**
- [ ] ¿Implementa interfaces de domain?
- [ ] ¿Mappers entre domain y modelos externos?
- [ ] ¿Handlers delegan a use cases?

✅ **Wire-up:**
- [ ] ¿Dependency injection en main.go?
- [ ] ¿Construcción de grafo de dependencias?
