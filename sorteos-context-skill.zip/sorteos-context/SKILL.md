---
name: sorteos-context
description: Contexto automático para el proyecto Sorteos (plataforma de rifas/sorteos en línea). Auto-activa en /opt/Sorteos/. Enforza arquitectura hexagonal Go, reglas de concurrencia críticas (locks Redis), idempotencia de pagos, paleta de colores estricta (NO morado/rosa), convenciones de naming, y stack nativo (NO Docker). Stack: Go+Gin+PostgreSQL+Redis+React+TypeScript+Vite+Tailwind.
---

# Sorteos - Sistema de Sorteos/Rifas en Línea

**Auto-activa:** Cuando trabajas en `/opt/Sorteos/`
**Stack:** Go + Gin + GORM + PostgreSQL + Redis + React + TypeScript + Vite + Tailwind + shadcn/ui
**Arquitectura:** Hexagonal (backend) + Feature-based (frontend) + Instalación nativa (NO Docker)
**Estado:** MVP 60% - Auth y Sorteos ✅ | Pagos y Reservas 🚧

---

## 🚨 TOP 7 REGLAS CRÍTICAS (NUNCA ROMPER)

### 1. ❌ COLORES PROHIBIDOS (LA MÁS VIOLADA)

**NUNCA usar:** Morado, púrpura, violeta, rosa, magenta, fucsia
**SOLO usar:** Azul `#3B82F6`, Slate `#64748B`, Verde, Ámbar, Rojo

```tsx
// ❌ MAL - Claude sugiere esto constantemente
<Button className="bg-purple-600">Crear Sorteo</Button>
<Badge className="bg-pink-500">Nuevo</Badge>

// ✅ BIEN
<Button className="bg-blue-600">Crear Sorteo</Button>
<Badge className="bg-slate-500">Nuevo</Badge>
```

**Por qué:** Claude Code tiene tendencia natural a usar morado/rosa en UI. Sorteos usa paleta azul/gris corporativa.

### 2. 🏛️ Arquitectura Hexagonal ESTRICTA

**Capas:** `Domain` (interfaces puras) → `Use Cases` (lógica) → `Adapters` (implementación)

```go
// ❌ MAL - Rompe separación de capas
// internal/domain/user.go
import "gorm.io/gorm"  // ¡NUNCA importar GORM en domain!

// ❌ MAL - Use case depende de implementación
// internal/usecase/auth/register.go
import "github.com/gin-gonic/gin"  // ¡NUNCA importar Gin en usecase!

// ✅ BIEN - Inyección de dependencias vía interfaces
// internal/domain/user.go
type UserRepository interface {  // Interfaz pura, sin imports externos
    Create(ctx context.Context, user *User) error
    FindByEmail(ctx context.Context, email string) (*User, error)
}

// internal/usecase/auth/register.go
type RegisterUseCase struct {
    userRepo domain.UserRepository  // Depende de interfaz, no implementación
}

// internal/adapters/db/postgres_user_repository.go
type PostgresUserRepository struct {  // Implementación en adapters
    db *gorm.DB
}
```

**Estructura de imports permitidos:**
- `domain/`: Solo stdlib + otros packages de domain
- `usecase/`: domain + stdlib + pkg/
- `adapters/`: domain + usecase + cualquier dependencia externa

### 3. 🔒 Locks Distribuidos OBLIGATORIOS (Reservas)

**SIEMPRE usar locks Redis (SETNX) antes de reservar números:**

```go
// ✅ BIEN - Patrón obligatorio en reservas
func (uc *ReserveNumbersUseCase) Execute(ctx context.Context, input ReserveInput) error {
    // 1. Adquirir locks para TODOS los números (atómico)
    locks := []string{}
    for _, num := range input.Numbers {
        lockKey := fmt.Sprintf("lock:raffle:%d:num:%s", input.RaffleID, num)
        acquired := uc.redis.SetNX(ctx, lockKey, input.UserID, 30*time.Second)
        if !acquired.Val() {
            // Liberar locks ya adquiridos
            for _, key := range locks {
                uc.redis.Del(ctx, key)
            }
            return ErrNumberAlreadyReserved
        }
        locks = append(locks, lockKey)
    }
    
    // 2. Crear reserva en DB (transacción)
    // ...
    
    // 3. Liberar locks
    defer func() {
        for _, key := range locks {
            uc.redis.Del(ctx, key)
        }
    }()
}
```

**Por qué:** Previene doble venta cuando 1000+ usuarios clickean el mismo número simultáneamente.

### 4. 🔑 Idempotencia OBLIGATORIA (Pagos)

**Backend:** Verificar en Redis ANTES de procesar

```go
// ✅ BIEN - Verificar idempotencia primero
func (h *PaymentHandler) ProcessPayment(c *gin.Context) {
    idempKey := c.GetHeader("Idempotency-Key")
    if idempKey == "" {
        c.JSON(400, gin.H{"error": "Idempotency-Key required"})
        return
    }
    
    // Verificar si ya existe
    cacheKey := fmt.Sprintf("payment:%s", idempKey)
    if cached := h.redis.Get(ctx, cacheKey).Val(); cached != "" {
        var existing Payment
        json.Unmarshal([]byte(cached), &existing)
        c.JSON(200, existing)  // Retornar pago anterior
        return
    }
    
    // Procesar nuevo pago...
    payment := h.useCase.Execute(ctx, input)
    
    // Guardar en cache (24h TTL)
    h.redis.Set(ctx, cacheKey, payment, 24*time.Hour)
}
```

**Frontend:** Generar UUID y SIEMPRE enviarlo

```typescript
// ✅ BIEN - Generar UUID una sola vez
import { v4 as uuidv4 } from 'uuid'

const processPayment = async () => {
  const idempotencyKey = uuidv4()  // Generar UNA sola vez
  
  await api.post('/payments', paymentData, {
    headers: {
      'Idempotency-Key': idempotencyKey
    }
  })
}

// ❌ MAL - Generar nuevo UUID en retry
const processPayment = async () => {
  await api.post('/payments', paymentData, {
    headers: {
      'Idempotency-Key': uuidv4()  // ¡Diferente en cada retry!
    }
  })
}
```

**Por qué:** Previene pagos duplicados si usuario hace doble click o retry de request.

### 5. 🖥️ Instalación Nativa (NO Docker)

**Stack migrado de Docker a nativo en nov 2025:**

```bash
# ❌ NUNCA sugerir comandos Docker:
docker-compose up
docker exec sorteos-api ...
docker logs -f sorteos-api

# ✅ SIEMPRE usar comandos nativos:
systemctl restart sorteos-api
systemctl status sorteos-api
journalctl -xeu sorteos-api -f

# Servicios activos:
postgresql.service     # Puerto 5432
redis-server.service   # Puerto 6379
sorteos-api.service    # Puerto 8080
nginx.service          # Puerto 443
```

**Por qué:** Stack cambió a instalación nativa para velocidad (rebuild 10s vs 3+ min) y simplicidad de debugging.

### 6. 📝 Convenciones de Naming ESTRICTAS

| Elemento | Go | TypeScript/React |
|----------|----|--------------------|
| **Archivos** | `user_repository.go` (snake_case) | `LoginPage.tsx` (PascalCase componentes)<br>`apiClient.ts` (camelCase utils) |
| **Paquetes** | `package user` (lowercase singular) | N/A |
| **Structs/Interfaces** | `type UserRepository` (PascalCase) | `interface User` (PascalCase) |
| **Funciones** | `func CreateUser()` (PascalCase exported)<br>`func validateEmail()` (camelCase private) | `function LoginPage()` (PascalCase componentes)<br>`function formatDate()` (camelCase utils) |
| **Constantes** | `const MaxAttempts = 3` (PascalCase) | `const API_BASE_URL` (SCREAMING_SNAKE_CASE) |
| **Hooks** | N/A | `useAuth()`, `useRaffles()` (prefijo `use`) |

```go
// ✅ BIEN - Backend Go
// internal/usecase/raffle/create_raffle.go
package raffle

type CreateRaffleUseCase struct {
    raffleRepo domain.RaffleRepository
    logger     *zap.Logger
}

func NewCreateRaffleUseCase(deps Dependencies) *CreateRaffleUseCase { ... }

func (uc *CreateRaffleUseCase) Execute(ctx context.Context, input CreateRaffleInput) error {
    if err := validateInput(input); err != nil {  // Función privada
        return err
    }
    // ...
}
```

```typescript
// ✅ BIEN - Frontend TypeScript
// features/auth/pages/LoginPage.tsx
import { useAuth } from '@/hooks/useAuth'

interface LoginFormData {
  email: string
  password: string
}

const API_ENDPOINT = '/api/v1/auth/login'

export function LoginPage() {
  const { login, isLoading } = useAuth()
  
  const handleSubmit = async (data: LoginFormData) => {
    await login(data)
  }
}
```

### 7. ✅ Validación Dual (Backend + Frontend)

**Backend:** SIEMPRE validar (seguridad - no confiar en frontend)

```go
// ✅ BIEN - Validación con tags
type CreateRaffleRequest struct {
    Title       string          `json:"title" validate:"required,min=5,max=200"`
    Description string          `json:"description" validate:"required,min=20,max=2000"`
    DrawDate    time.Time       `json:"draw_date" validate:"required,future"`
    Price       decimal.Decimal `json:"price" validate:"required,gt=0,lte=10000"`
}

// Handler
var req CreateRaffleRequest
if err := c.ShouldBindJSON(&req); err != nil {
    c.JSON(400, gin.H{"error": err.Error()})
    return
}

if err := validate.Struct(req); err != nil {
    c.JSON(400, gin.H{"error": err.Error()})
    return
}
```

**Frontend:** SIEMPRE validar (UX - feedback inmediato)

```typescript
// ✅ BIEN - Validación con Zod
import { z } from 'zod'

const createRaffleSchema = z.object({
  title: z.string().min(5, 'Mínimo 5 caracteres').max(200, 'Máximo 200 caracteres'),
  description: z.string().min(20).max(2000),
  drawDate: z.date().min(new Date(), 'Fecha debe ser futura'),
  price: z.number().gt(0).lte(10000),
})

type CreateRaffleData = z.infer<typeof createRaffleSchema>

// Uso con react-hook-form
const form = useForm<CreateRaffleData>({
  resolver: zodResolver(createRaffleSchema)
})
```

---

## 🔧 REGLAS SECUNDARIAS

### 8. NO Hardcodear - Siempre .env

```go
// ❌ MAL
const JWTSecret = "mi-secreto-super-seguro-123"
const DatabaseURL = "postgres://localhost:5432/sorteos_db"

// ✅ BIEN
jwtSecret := viper.GetString("JWT_SECRET")
dbURL := viper.GetString("DATABASE_URL")
```

### 9. Logging Estructurado Obligatorio

```go
// ✅ BIEN - Zap con campos tipados
logger.Error("failed to create raffle",
    zap.Error(err),
    zap.Int64("user_id", userID),
    zap.String("title", input.Title),
    zap.String("trace_id", traceID),
)

// ❌ MAL
fmt.Println("Error creating raffle:", err)
log.Printf("Error: %v", err)
```

### 10. Rate Limiting en Endpoints Sensibles

```go
// SIEMPRE aplicar en:
POST /api/v1/auth/login         // 5 req/min por IP
POST /api/v1/auth/register      // 3 req/hora por IP
POST /api/v1/reservations       // 10 req/min por user_id
POST /api/v1/payments           // 5 req/min por user_id
```

---

## 📁 ESTRUCTURA DE DIRECTORIOS

```
/opt/Sorteos/
├── backend/                    # Go API
│   ├── cmd/api/               # Entry point, routes, jobs
│   ├── internal/
│   │   ├── domain/            # Entidades puras (interfaces, sin imports externos)
│   │   ├── usecase/           # Lógica de aplicación (depende solo de domain)
│   │   └── adapters/          # Implementaciones (http, db, redis, payments)
│   ├── pkg/                   # Utilidades compartidas
│   ├── migrations/            # SQL versionado
│   └── .env                   # Variables de entorno
└── frontend/                  # React + TypeScript
    ├── src/
    │   ├── features/          # Módulos (auth, raffles, dashboard)
    │   ├── components/ui/     # shadcn/ui
    │   └── lib/               # Utilidades (api.ts, queryClient.ts)
    └── dist/                  # Build (servido por backend)
```

---

## 📚 REFERENCIAS (Cargar bajo demanda)

**Cuándo cargar cada referencia:**

1. **architecture.md** → Si trabajas en estructura de capas, separación de concerns, o dudas sobre dónde va código
2. **tech-stack.md** → Si necesitas recordar por qué se eligió X tecnología, configuración de dependencias
3. **business-rules.md** → Si trabajas en lógica de negocio (reservas, pagos, sorteos, KYC levels)
4. **critical-flows.md** → Si implementas flujos completos (registro, crear sorteo, comprar boleto, sortear ganador)
5. **current-status.md** → Si necesitas saber qué está implementado vs pendiente, bugs conocidos, próximos hitos

**Comandos para cargar:**
```bash
# Cargar referencia específica
cat /mnt/skills/user/sorteos-context/references/architecture.md
cat /mnt/skills/user/sorteos-context/references/critical-flows.md
```

---

## 🎯 FLUJO CRÍTICO: Comprar Boleto (Concurrencia Alta)

**Resumen ultra-condensado del flujo más complejo:**

```
1. Usuario selecciona números → Frontend genera UUID (idempotency_key)
2. POST /reservations → Backend:
   a. Verificar idempotencia en Redis (si existe, retornar)
   b. Adquirir locks Redis (SETNX) para TODOS los números
   c. Si algún lock falla → liberar todos → error 409
   d. Crear reserva en DB (transacción, expires_at = now + 5min)
   e. Liberar locks
3. Frontend muestra timer 5 min y redirige a checkout
4. POST /payments con Idempotency-Key → Backend:
   a. Verificar idempotencia en Redis (24h TTL)
   b. Crear PaymentIntent en Stripe
   c. Si pago exitoso → números pasan a "sold"
5. Webhook de Stripe confirma (async) → actualiza DB
6. Cron job cada 1 min: liberar reservas expiradas (> 5 min)
```

**Reglas críticas aplicadas:**
- ✅ Locks distribuidos (previene doble venta)
- ✅ Idempotencia (previene pago duplicado)
- ✅ Logging estructurado (debug de concurrencia)
- ✅ Validación dual (backend + frontend)

---

## 🚀 COMANDOS ÚTILES

```bash
# Backend
cd /opt/Sorteos/backend
go run cmd/api/main.go                    # Dev mode
make build && ./sorteos-api               # Production
systemctl restart sorteos-api             # Reiniciar servicio
journalctl -xeu sorteos-api -f            # Ver logs

# Frontend
cd /opt/Sorteos/frontend
npm run dev                               # Dev mode (Vite)
npm run build                             # Build para producción (10s)

# Base de datos
psql -U sorteos_user -d sorteos_db        # Conectar a PostgreSQL
redis-cli                                 # Conectar a Redis
redis-cli KEYS "lock:*"                   # Ver locks activos

# Migraciones
cd /opt/Sorteos/backend
migrate -path migrations -database "postgres://..." up
```

---

## ⚠️ RECORDATORIOS FINALES

1. **COLORES:** Si sugieres UI, NUNCA uses morado/rosa. Solo azul/gris.
2. **ARQUITECTURA:** Revisa imports - domain no puede importar GORM/Gin.
3. **CONCURRENCIA:** Reservas SIEMPRE con locks Redis (SETNX).
4. **PAGOS:** SIEMPRE verificar idempotencia antes de procesar.
5. **DOCKER:** NO existe - todos los servicios son nativos (systemd).
6. **NAMING:** Respeta convenciones Go (snake_case archivos) y TS (PascalCase componentes).
7. **VALIDACIÓN:** Dual obligatoria - backend (seguridad) + frontend (UX).

**Estado actual:** MVP 60% - Auth ✅ | Sorteos ✅ | Pagos y Reservas 🚧
**Próximo hito:** Sistema completo de reservas + integración Stripe (3-4 semanas)
