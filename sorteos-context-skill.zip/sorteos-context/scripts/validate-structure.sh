#!/bin/bash

# validate-structure.sh
# Valida que la estructura del proyecto Sorteos esté correcta

set -e

PROJECT_ROOT="/opt/Sorteos"
ERRORS=0

echo "🔍 Validando estructura del proyecto Sorteos..."
echo

# Función para reportar error
error() {
    echo "❌ $1"
    ERRORS=$((ERRORS + 1))
}

# Función para reportar éxito
success() {
    echo "✅ $1"
}

# Validar directorio raíz
if [ ! -d "$PROJECT_ROOT" ]; then
    error "Directorio raíz no existe: $PROJECT_ROOT"
    exit 1
fi

success "Directorio raíz existe: $PROJECT_ROOT"

# Validar estructura backend
echo
echo "📁 Validando backend..."

if [ ! -d "$PROJECT_ROOT/backend" ]; then
    error "Directorio backend no existe"
else
    success "Directorio backend existe"
    
    # Validar subdirectorios críticos
    for dir in cmd internal pkg migrations; do
        if [ ! -d "$PROJECT_ROOT/backend/$dir" ]; then
            error "Directorio backend/$dir no existe"
        else
            success "Directorio backend/$dir existe"
        fi
    done
    
    # Validar estructura interna de internal/
    for dir in domain usecase adapters; do
        if [ ! -d "$PROJECT_ROOT/backend/internal/$dir" ]; then
            error "Directorio backend/internal/$dir no existe"
        else
            success "Directorio backend/internal/$dir existe"
        fi
    done
    
    # Validar archivos críticos
    if [ ! -f "$PROJECT_ROOT/backend/.env" ]; then
        error "Archivo backend/.env no existe"
    else
        success "Archivo backend/.env existe"
    fi
    
    if [ ! -f "$PROJECT_ROOT/backend/go.mod" ]; then
        error "Archivo backend/go.mod no existe"
    else
        success "Archivo backend/go.mod existe"
    fi
fi

# Validar estructura frontend
echo
echo "📁 Validando frontend..."

if [ ! -d "$PROJECT_ROOT/frontend" ]; then
    error "Directorio frontend no existe"
else
    success "Directorio frontend existe"
    
    # Validar subdirectorios críticos
    for dir in src public; do
        if [ ! -d "$PROJECT_ROOT/frontend/$dir" ]; then
            error "Directorio frontend/$dir no existe"
        else
            success "Directorio frontend/$dir existe"
        fi
    done
    
    # Validar estructura de src/
    for dir in features components lib store; do
        if [ ! -d "$PROJECT_ROOT/frontend/src/$dir" ]; then
            error "Directorio frontend/src/$dir no existe"
        else
            success "Directorio frontend/src/$dir existe"
        fi
    done
    
    # Validar archivos críticos
    if [ ! -f "$PROJECT_ROOT/frontend/package.json" ]; then
        error "Archivo frontend/package.json no existe"
    else
        success "Archivo frontend/package.json existe"
    fi
    
    if [ ! -f "$PROJECT_ROOT/frontend/vite.config.ts" ]; then
        error "Archivo frontend/vite.config.ts no existe"
    else
        success "Archivo frontend/vite.config.ts existe"
    fi
fi

# Validar servicios activos
echo
echo "🔧 Validando servicios..."

services=("postgresql" "redis-server" "sorteos-api" "nginx")

for service in "${services[@]}"; do
    if systemctl is-active --quiet "$service"; then
        success "Servicio $service está activo"
    else
        error "Servicio $service NO está activo"
    fi
done

# Validar conectividad a DB
echo
echo "🗄️ Validando conectividad a PostgreSQL..."

if psql -U sorteos_user -d sorteos_db -c "SELECT 1;" > /dev/null 2>&1; then
    success "Conexión a PostgreSQL exitosa"
else
    error "No se puede conectar a PostgreSQL"
fi

# Validar conectividad a Redis
echo
echo "🔴 Validando conectividad a Redis..."

if redis-cli ping > /dev/null 2>&1; then
    success "Conexión a Redis exitosa"
else
    error "No se puede conectar a Redis"
fi

# Validar binario compilado
echo
echo "🔨 Validando binario backend..."

if [ -f "$PROJECT_ROOT/backend/sorteos-api" ]; then
    success "Binario sorteos-api existe"
else
    error "Binario sorteos-api no existe - ejecutar: make build"
fi

# Validar build frontend
echo
echo "🎨 Validando build frontend..."

if [ -d "$PROJECT_ROOT/frontend/dist" ]; then
    success "Directorio dist existe"
    
    if [ -f "$PROJECT_ROOT/frontend/dist/index.html" ]; then
        success "index.html existe en dist"
    else
        error "index.html no existe en dist - ejecutar: npm run build"
    fi
else
    error "Directorio dist no existe - ejecutar: npm run build"
fi

# Resumen
echo
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
if [ $ERRORS -eq 0 ]; then
    echo "✅ Validación completada exitosamente"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    exit 0
else
    echo "❌ Validación falló con $ERRORS errores"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    exit 1
fi
