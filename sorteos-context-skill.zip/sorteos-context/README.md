# Skill: sorteos-context

Contexto automático para el proyecto Sorteos (plataforma de rifas/sorteos en línea).

## Auto-activación

Este skill se activa automáticamente cuando Claude Code detecta que estás trabajando en `/opt/Sorteos/`.

## Contenido

### SKILL.md (Siempre cargado)
Contiene las **7 reglas críticas** que Claude debe respetar SIEMPRE:

1. ❌ **COLORES PROHIBIDOS** - NUNCA morado/rosa, SOLO azul/gris
2. 🏛️ **Arquitectura Hexagonal ESTRICTA** - domain no importa GORM/Gin
3. 🔒 **Locks Distribuidos OBLIGATORIOS** - SETNX en Redis para reservas
4. 🔑 **Idempotencia OBLIGATORIA** - Pagos con Idempotency-Key
5. 🖥️ **Instalación Nativa** - NO Docker, usar systemd
6. 📝 **Convenciones de Naming** - snake_case Go, PascalCase React
7. ✅ **Validación Dual** - Backend (seguridad) + Frontend (UX)

### references/ (Cargado bajo demanda)

- **architecture.md** - Arquitectura hexagonal, separación de capas, wire-up
- **business-rules.md** - Reglas críticas de negocio (concurrencia, pagos, KYC)
- **current-status.md** - Estado actual, bugs conocidos, próximos hitos

### scripts/ (Ejecutable)

- **validate-structure.sh** - Valida estructura del proyecto y servicios activos

## Stack

- **Backend:** Go + Gin + GORM + PostgreSQL + Redis
- **Frontend:** React + TypeScript + Vite + Tailwind + shadcn/ui
- **Infraestructura:** Nativa (systemd) - NO Docker

## Estado Actual

- **Progreso:** MVP 60% completo
- **Completado:** Auth ✅ | Sorteos ✅
- **En progreso:** Reservas 🚧 | Pagos 🚧

## Uso

### Cargar referencias específicas

```bash
# Arquitectura hexagonal
cat /mnt/skills/user/sorteos-context/references/architecture.md

# Reglas de negocio
cat /mnt/skills/user/sorteos-context/references/business-rules.md

# Estado actual
cat /mnt/skills/user/sorteos-context/references/current-status.md
```

### Validar estructura del proyecto

```bash
/mnt/skills/user/sorteos-context/scripts/validate-structure.sh
```

## Filosofía del Skill

Este skill sigue el principio de **"Claude ya es muy inteligente"**:

✅ **SÍ incluye:**
- Reglas específicas de Sorteos (colores prohibidos, arquitectura, convenciones)
- Decisiones técnicas tomadas (por qué Go, por qué hexagonal)
- Reglas de negocio críticas (locks, idempotencia)
- Contexto actual del proyecto

❌ **NO incluye:**
- Explicaciones de Go, React, PostgreSQL (Claude ya las conoce)
- Documentación de APIs públicas (Stripe, Redis - Claude las conoce)
- Tutoriales básicos de programación

## Regla #1 (La más violada)

**🚨 COLORES PROHIBIDOS: NUNCA morado/púrpura/rosa/magenta**

Claude Code tiene tendencia natural a usar colores morados/rosas en UI.
Sorteos usa paleta **azul/gris** corporativa exclusivamente.

Cada vez que sugieras UI, recuerda:
- ❌ `bg-purple-600`, `bg-pink-500`, `text-violet-400`
- ✅ `bg-blue-600`, `bg-slate-500`, `text-gray-400`

## Contacto

**Propietario:** Ing. Alonso Alpízar
**Proyecto:** https://sorteos.club
**Documentación:** `/opt/Sorteos/Documentacion/`
